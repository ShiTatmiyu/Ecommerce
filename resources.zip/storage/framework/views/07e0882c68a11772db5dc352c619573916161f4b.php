<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- success message & Error message -->
        
    
<div>
    <h3>1 Item in your cart</h3>
</div>

<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="cart">
        <div class="row">
            <div class="col-lg-3">
            <img class="img-cart" src="<?php echo e(asset('storage/images/product.jpg')); ?>" alt="">
            </div>
            <div class="col-lg-9">
                <div class="top">
                    <p class="item-name">Nama Produk</p>
                    <div class="top-right">
                        <p class="">Rp200000</p>
                        <select name="qty" class="quantity" data-item="id-cartnya">
                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                        </select>
                        <!-- Subtotal -->
                        <p class="total-item">RpSubtotal</p>
                    </div>
                </div>
                <hr class="mt-2 mb-2">
                <div class="bottom">
                   <div class="row">
                        <p class="col-lg-6 item-desc">
                            Deskripsi
                        </p>
                        <div class="offset-lg-4">

                        </div>
                        <div class="col-lg-2">
                        <!-- delete cart -->
                        <form action="" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Remove</button>
                            </form>
                        </div>
                   </div>
                </div>
            </div>
        </div>
    </div>
    
<div class="totalz">
    <h4 class="total-price">Total Price: Rp10000000</h4>
</div>
</div>

<form action="" method="POST" style="margin-left: 700px;">
<?php echo csrf_field(); ?>
<button type="submit" class="btn btn-primary">Checkout</button>
</form>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    (function(){
    const classname = document.querySelectorAll('.quantity');

    Array.from(classname).forEach(function(element){
     element.addEventListener('change', function(){
        const id = element.getAttribute('data-item');
        axios.patch(``, {
            quantity: this.value,
            id: id
          })
          .then(function (response) {
            //console.log(response);
            window.location.href = ''
          })
          .catch(function (error) {
            console.log(error);
          });
   })
 })
    })();
</script>
<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ecommerce adi\resources\views//cart/index.blade.php ENDPATH**/ ?>